# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['opentutor_classifier',
 'opentutor_classifier.composite',
 'opentutor_classifier.lr2',
 'opentutor_classifier.openai']

package_data = \
{'': ['*']}

install_requires = \
['backoff>=2.2.1,<3.0.0',
 'blinker>=1.4,<2.0',
 'boto3-type-annotations>=0.3.1,<0.4.0',
 'boto3==1.20.53',
 'botocore==1.23.53',
 'celery>=5.0.5,<6.0.0',
 'click<8',
 'dataclass-wizard>=0.22.2,<0.23.0',
 'gensim>=4.0.1,<5.0.0',
 'numpy>=1.23.0,<2.0.0',
 'openai>=0.27.8,<0.28.0',
 'pandas>=1.2.4,<2.0.0',
 'pylru>=1.2.0,<2.0.0',
 'python-dotenv>=0.17.1,<0.18.0',
 'pyyaml>=5.4.1,<6.0.0',
 'redis>=5.0.4,<6.0.0',
 'requests>=2.26.0,<3.0.0',
 'scikit-learn>=1.2.2,<2.0.0',
 'scipy>=1.10.1,<2.0.0',
 'sentry-sdk>=1.5.1,<2.0.0',
 'text2num>=2.2.1,<3.0.0',
 'tiktoken>=0.5.1,<0.6.0',
 'tok>=0.1.14,<0.2.0',
 'tomlkit>=0.8.0,<0.9.0',
 'werkzeug>=3.0.3,<4.0.0']

setup_kwargs = {
    'name': 'opentutor-classifier',
    'version': '1.0.0',
    'description': 'train and run inference for open tutor',
    'long_description': 'None',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8.4,<3.9.0',
}


setup(**setup_kwargs)
